import os
from footprono.config import Config
from footprono.web import serve

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    host = "0.0.0.0"
    serve(Config.load(os.environ.get("FOOTPRONO_CONFIG")), "footprono.db", host, port)
