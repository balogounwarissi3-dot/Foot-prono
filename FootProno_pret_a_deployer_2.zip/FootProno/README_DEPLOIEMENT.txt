FOOTPRONO — paquet préparé pour déploiement web

CONTENU
- Dossier footprono/ : moteur Python, règles, interface mobile PWA et stockage SQLite.
- app.py : point de démarrage compatible avec un hébergeur Python.
- requirements.txt : aucune dépendance externe requise.

LANCEMENT LOCAL
Python 3.10+ :
    python app.py
Puis ouvrir http://127.0.0.1:8000

DÉPLOIEMENT
Importer le contenu de ce ZIP dans un espace de développement Python (par exemple Replit),
vérifier que la commande de démarrage est `python app.py`, puis lancer le déploiement web.
Définir un secret FOOTPRONO_TOKEN long et aléatoire dans les variables d'environnement.
Ouvrir l'application avec ?token=VOTRE_SECRET si le jeton est activé.

IMPORTANT
- Ce paquet n'inclut PAS de connexion automatique à 1xBet. Les matchs doivent être importés
  manuellement au format JSON prévu dans README.md.
- Les données d'exemple sont fictives et ne doivent pas être utilisées comme pronostics réels.
- Le stockage SQLite local peut être éphémère selon l'hébergeur : utiliser un disque persistant
  avant de conserver des historiques importants.
- L'interface PWA permet l'ajout à l'écran d'accueil Android après déploiement HTTPS.
  Ce paquet ne produit pas directement un APK natif.
