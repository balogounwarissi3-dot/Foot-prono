"""Moteur de règles déterministe pour l'analyse football (usage personnel)."""
__version__ = "0.1.0"
