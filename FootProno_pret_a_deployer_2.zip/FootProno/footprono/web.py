"""Interface web mobile (stdlib uniquement). Lancer en local ; pour l'ouvrir depuis le téléphone,
utiliser --host 0.0.0.0 sur un réseau de confiance et définir FOOTPRONO_TOKEN."""
from __future__ import annotations
import json, os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from .service import run
from .storage import Store

PAGE = """<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0a7d4b"><meta name="description" content="Analyse football et suivi des pronostics FootProno">
<link rel="manifest" href="/manifest.webmanifest"><link rel="icon" href="/icon.svg" type="image/svg+xml">
<title>FootProno</title>
<style>:root{--bg:#fff;--fg:#111;--card:#f2f3f5;--ac:#0a7d4b}@media(prefers-color-scheme:dark){:root{--bg:#121315;--fg:#eee;--card:#1e2024;--ac:#3ecf8e}}
body{font:16px system-ui;background:var(--bg);color:var(--fg);margin:0;padding:12px;max-width:640px;margin:auto}
.card{background:var(--card);border-radius:12px;padding:12px;margin:10px 0}button,select,textarea{font:inherit;padding:10px;border-radius:10px;border:1px solid #8886;background:var(--bg);color:var(--fg)}
button{background:var(--ac);color:#fff;border:0;width:100%;margin-top:8px}textarea{width:100%;box-sizing:border-box;height:90px}
small{opacity:.7}.tag{color:var(--ac);font-weight:600}</style></head><body>
<header style="display:flex;align-items:center;gap:12px"><img src="/icon.svg" width="44" height="44" alt="FootProno"><div><h2 style="margin:0">FootProno</h2><small>Analyse football</small></div></header>
<small>Aucun pronostic n'est garanti.</small>
<div id="install" hidden class="card"><b>Installer FootProno</b><p>Ajoute l'application à l'écran d'accueil de ton téléphone.</p><button id="installBtn">Installer</button></div>
<div class="card"><label>Durée <select id="w"><option>30</option><option>60</option><option selected>120</option><option>180</option></select> min</label>
<label> Matchs <select id="m"><option value="both">à venir + live</option><option value="upcoming">à venir</option><option value="live">live</option></select></label>
<textarea id="d" placeholder="Coller ici les données 1xBet importées (JSON)"></textarea>
<label><input type="checkbox" id="s"> Enregistrer les pronostics</label><button onclick="go()">Analyser</button></div>
<div id="out"></div><script>
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}))}
let installPrompt=null;const installBox=document.getElementById('install');
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;installBox.hidden=false});
document.getElementById('installBtn').addEventListener('click',async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;installBox.hidden=true});
const T=new URLSearchParams(location.search).get('token')||'';
const e=s=>String(s??'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
async function go(){const o=document.getElementById('out');o.textContent='…';let p;
try{p=JSON.parse(document.getElementById('d').value)}catch(x){o.textContent='JSON invalide';return}
const r=await fetch('/api/analyze?token='+T,{method:'POST',body:JSON.stringify({payload:p,window:+w.value,mode:m.value,save:s.checked})});
const c=await r.json();if(c.error){o.textContent=c.error;return}
let h='<small>Source : '+e(c.source)+' · '+e(c.generated_at)+'</small>';
if(!c.selections.length)h+='<div class="card">Aucune sélection : aucune règle applicable.</div>';
for(const d of c.selections)h+=`<div class="card"><b>${e(d.home)} - ${e(d.away)}</b><br><span class="tag">${e(d.selection)}</span><br><small>${e(d.logic)} · ${e(d.confidence)} · collecte ${e(d.collected_at||'?')}</small><br><small>${d.trace.map(e).join('<br>')}</small></div>`;
if(c.skipped.length)h+='<div class="card"><b>Ignorés</b><br>'+c.skipped.map(s=>'<small>'+e(s.match)+' : '+e(s.reason)+'</small>').join('<br>')+'</div>';
o.innerHTML=h+'<small>'+e(c.disclaimer)+'</small>'}
</script></body></html>"""


def serve(cfg, db, host, port):
    token = os.environ.get("FOOTPRONO_TOKEN")

    class H(BaseHTTPRequestHandler):
        def _ok(self):
            if token and parse_qs(urlparse(self.path).query).get("token", [""])[0] != token:
                self._send(401, "text/plain", b"Acces refuse")
                return False
            return True

        def _send(self, code, ctype, body):
            self.send_response(code); self.send_header("Content-Type", ctype + "; charset=utf-8")
            self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

        def do_GET(self):
            if not self._ok(): return
            path = urlparse(self.path).path
            if path == "/":
                self._send(200, "text/html", PAGE.encode())
            elif path == "/manifest.webmanifest":
                manifest = {"name":"FootProno","short_name":"FootProno","start_url":"/","display":"standalone",
                            "background_color":"#ffffff","theme_color":"#0a7d4b",
                            "description":"Analyse football et suivi des pronostics",
                            "icons":[{"src":"/icon.svg","sizes":"any","type":"image/svg+xml","purpose":"any maskable"}]}
                self._send(200, "application/manifest+json", json.dumps(manifest).encode())
            elif path == "/icon.svg":
                icon = b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="112" fill="#0a7d4b"/><circle cx="256" cy="256" r="150" fill="none" stroke="white" stroke-width="22"/><path d="M256 145l66 48-25 78h-82l-25-78z M190 193l-70 25 12 84 82 36 M322 193l70 25-12 84-82 36 M231 349l25 18 25-18" fill="none" stroke="white" stroke-width="18" stroke-linejoin="round"/></svg>'
                self._send(200, "image/svg+xml", icon)
            elif path == "/sw.js":
                sw = b"const CACHE='footprono-shell-v1';const ASSETS=['/','/manifest.webmanifest','/icon.svg'];self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).pathname.startsWith('/api/'))return;e.respondWith(fetch(e.request).catch(()=>caches.match(e.request).then(r=>r||caches.match('/'))))});"
                self._send(200, "application/javascript", sw)
            elif path == "/api/stats":
                self._send(200, "application/json", json.dumps(Store(db).stats()).encode())
            else:
                self._send(404, "text/plain", b"?")

        def do_POST(self):
            if not self._ok(): return
            try:
                body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
                res = run(body["payload"], cfg, int(body.get("window", 120)), body.get("mode", "both"),
                          db, bool(body.get("save")))
            except Exception as ex:  # données invalides -> message clair, jamais de pronostic inventé
                res = {"error": f"Import invalide : {ex}"}
            self._send(200, "application/json", json.dumps(res, ensure_ascii=False).encode())

    print(f"Interface sur http://{host}:{port}" + (" (jeton requis : ?token=...)" if token else ""))
    ThreadingHTTPServer((host, port), H).serve_forever()
