"""Modèles de données. Toute donnée absente ou invalide reste None / liste vide :
rien n'est jamais inventé ni complété."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone


def parse_dt(v):
    if v in (None, ""):
        return None
    d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def to_int(v):
    if v is None or isinstance(v, bool):
        return None
    try:
        if isinstance(v, float) and not v.is_integer():
            return None
        i = int(v)
    except (TypeError, ValueError):
        return None
    return i if i >= 0 else None


def goals_list(v, label, warnings):
    """Liste de buts marqués, du match le plus récent au plus ancien.
    Une seule valeur invalide => liste rejetée en entier (pas de réparation silencieuse)."""
    if v is None:
        return []
    if not isinstance(v, list):
        warnings.append(f"{label}: format invalide")
        return []
    out = [to_int(x) for x in v]
    if any(x is None for x in out):
        warnings.append(f"{label}: valeurs invalides, historique ignoré")
        return []
    return out


@dataclass
class TeamLive:
    dangerous_attacks: int | None = None
    shots_on: int | None = None
    shots_off: int | None = None

    def complete(self):
        return None not in (self.dangerous_attacks, self.shots_on, self.shots_off)


@dataclass
class Live:
    minute: int | None = None
    home_goals: int | None = None
    away_goals: int | None = None
    home: TeamLive = field(default_factory=TeamLive)
    away: TeamLive = field(default_factory=TeamLive)
    stats_at: datetime | None = None


@dataclass
class H2H:
    home: str
    away: str
    home_goals: int
    away_goals: int


@dataclass
class Match:
    id: str
    competition: str
    home: str
    away: str
    status: str                      # "scheduled" | "live"
    kickoff: datetime | None = None
    collected_at: datetime | None = None
    favorite: str | None = None      # "home" | "away" | None
    h2h: list = field(default_factory=list)
    home_scored: list = field(default_factory=list)
    away_scored: list = field(default_factory=list)
    live: Live | None = None
    warnings: list = field(default_factory=list)
    raw: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict, default_collected_at=None) -> "Match":
        w: list = []
        h2h = []
        for x in d.get("h2h") or []:
            hg, ag = to_int(x.get("home_goals")), to_int(x.get("away_goals"))
            if hg is None or ag is None or not x.get("home") or not x.get("away"):
                w.append("h2h: entrée invalide ignorée")
                continue
            h2h.append(H2H(x["home"], x["away"], hg, ag))
        live = None
        if d.get("live"):
            l = d["live"]
            def tl(k):
                s = l.get(k) or {}
                return TeamLive(to_int(s.get("dangerous_attacks")), to_int(s.get("shots_on_target")),
                                to_int(s.get("shots_off_target")))
            live = Live(to_int(l.get("minute")), to_int(l.get("home_goals")), to_int(l.get("away_goals")),
                        tl("home"), tl("away"), parse_dt(l.get("stats_at")))
        fav = d.get("favorite")
        return cls(
            id=str(d["id"]), competition=d.get("competition") or "?", home=d["home"], away=d["away"],
            status=d.get("status", "scheduled"), kickoff=parse_dt(d.get("kickoff")),
            collected_at=parse_dt(d.get("collected_at")) or default_collected_at,
            favorite=fav if fav in ("home", "away") else None, h2h=h2h,
            home_scored=goals_list(d.get("home_last_scored"), "home_last_scored", w),
            away_scored=goals_list(d.get("away_last_scored"), "away_last_scored", w),
            live=live, warnings=w, raw=d)

    def team(self, side):
        return self.home if side == "home" else self.away


@dataclass
class Decision:
    match_id: str
    competition: str
    home: str
    away: str
    kind: str              # "prematch" | "live"
    logic: str             # L1 | L2 | L3 | LIVE_NEXT_GOAL | LIVE_OVER_0_5 | LIVE_UNDERDOG
    market: str            # team_over_0_5 | total_over | total_range | next_goal
    selection: str         # libellé lisible
    params: dict
    stats: dict
    trace: list
    collected_at: str | None = None
    confidence: str = "confiance non évaluée"

    def to_dict(self):
        return asdict(self)


@dataclass
class Analysis:
    match_id: str
    decision: Decision | None
    skip_reason: str | None
    thresholds: dict | None
    trace: list
