"""Données FICTIVES pour tester le moteur. Rien ici ne vient de 1xBet."""
from __future__ import annotations
from datetime import datetime, timedelta, timezone


def demo_payload(now=None):
    now = now or datetime.now(timezone.utc)
    iso = lambda m: (now + timedelta(minutes=m)).isoformat()
    T = lambda n: f"{n} (FICTIF)"
    live = lambda minute, hg, ag, da, on, off, age=30: {
        "minute": minute, "home_goals": hg, "away_goals": ag, "stats_at": iso(-age / 60),
        "home": {"dangerous_attacks": da[0], "shots_on_target": on[0], "shots_off_target": off[0]},
        "away": {"dangerous_attacks": da[1], "shots_on_target": on[1], "shots_off_target": off[1]}}
    ms = [
     dict(id="D1", competition="Ligue FICTIVE", home=T("Alpha"), away=T("Bravo"), status="scheduled", kickoff=iso(40),
          home_last_scored=[2, 1, 3, 1, 2], away_last_scored=[0, 1, 0, 2, 1]),
     dict(id="D2", competition="Ligue FICTIVE", home=T("Charlie"), away=T("Delta"), status="scheduled", kickoff=iso(70),
          home_last_scored=[1, 0, 2, 1, 1], away_last_scored=[0, 0, 1, 0, 2]),
     dict(id="D3", competition="Ligue FICTIVE", home=T("Echo"), away=T("Foxtrot"), status="scheduled", kickoff=iso(100),
          home_last_scored=[1, 0, 2, 0, 1], away_last_scored=[0, 1, 1, 0, 2]),
     dict(id="D4", competition="Ligue FICTIVE", home=T("Golf"), away=T("Hotel"), status="scheduled", kickoff=iso(50),
          home_last_scored=[1, 2], away_last_scored=[]),
     dict(id="L1", competition="Coupe FICTIVE", home=T("India"), away=T("Juliet"), status="live", favorite="home",
          live=live(30, 0, 0, (14, 5), (4, 1), (5, 2))),
     dict(id="L2", competition="Coupe FICTIVE", home=T("Kilo"), away=T("Lima"), status="live",
          live=live(40, 0, 0, (9, 5), (3, 1), (4, 2))),
     dict(id="L3", competition="Coupe FICTIVE", home=T("Mike"), away=T("November"), status="live", favorite="home",
          live=live(55, 0, 1, (6, 7), (1, 2), (2, 3))),
     dict(id="L4", competition="Coupe FICTIVE", home=T("Oscar"), away=T("Papa"), status="live",
          live=live(35, 0, 0, (20, 4), (5, 1), (6, 1), age=900)),
     dict(id="L5", competition="Coupe FICTIVE", home=T("Quebec"), away=T("Romeo"), status="live",
          live=live(10, 0, 0, (10, 2), (3, 0), (3, 0))),
    ]
    return {"source": "DONNÉES FICTIVES (démo)", "collected_at": now.isoformat(), "matches": ms}
