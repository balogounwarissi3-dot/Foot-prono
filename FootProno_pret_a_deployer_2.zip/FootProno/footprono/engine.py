from __future__ import annotations
from dataclasses import dataclass, field
from datetime import timedelta
from .models import Analysis, Match
from . import rules


def analyze(match: Match, cfg, now, stored_thresholds=None) -> Analysis:
    if match.status == "live":
        dec, reason, trace = rules.evaluate_live(match, cfg, now, stored_thresholds)
        return Analysis(match.id, dec, reason, stored_thresholds, trace)
    trace = list(match.warnings)
    need = min(cfg.sample_size, cfg.threshold_sample_size)
    if len(match.home_scored) < need or len(match.away_scored) < need:
        return Analysis(match.id, None,
                        f"historique des derniers matchs insuffisant ou indisponible (minimum {need} par équipe)",
                        None, trace)
    thresholds = rules.compute_thresholds(match, cfg)
    for fn in (rules.logic1, rules.logic2):
        dec, t = fn(match, cfg)
        trace += t
        if dec:
            return Analysis(match.id, dec, None, thresholds, trace)
    dec, t = rules.logic3(match, cfg, thresholds)
    trace += t
    if dec:
        return Analysis(match.id, dec, None, thresholds, trace)
    return Analysis(match.id, None, "aucune règle applicable", thresholds, trace)


@dataclass
class Coupon:
    generated_at: str
    window_minutes: int
    mode: str
    selections: list = field(default_factory=list)
    skipped: list = field(default_factory=list)
    out_of_window: int = 0
    analyses: list = field(default_factory=list)

    def to_dict(self):
        return {"generated_at": self.generated_at, "window_minutes": self.window_minutes, "mode": self.mode,
                "selections": [d.to_dict() for d in self.selections], "skipped": self.skipped,
                "out_of_window": self.out_of_window,
                "disclaimer": "Aucun pronostic n'est garanti. Un coupon n'est jamais fiable à 100 %."}


def build_coupon(matches, cfg, now, window_minutes, mode="both", stored_thresholds=None, confidence_fn=None):
    """mode: 'upcoming' | 'live' | 'both'. Le coupon n'est jamais complété artificiellement."""
    stored_thresholds = stored_thresholds or {}
    c = Coupon(now.isoformat(), window_minutes, mode)
    end = now + timedelta(minutes=window_minutes)
    for m in matches:
        if m.status == "live":
            if mode == "upcoming":
                c.out_of_window += 1
                continue
        else:
            if mode == "live" or m.kickoff is None:
                if m.kickoff is None and mode != "live":
                    c.skipped.append({"match_id": m.id, "match": f"{m.home} - {m.away}",
                                      "reason": "heure du match inconnue"})
                else:
                    c.out_of_window += 1
                continue
            if m.kickoff < now:
                c.skipped.append({"match_id": m.id, "match": f"{m.home} - {m.away}",
                                  "reason": "match déjà commencé mais marqué « à venir » : statut obsolète"})
                continue
            if m.kickoff > end:
                c.out_of_window += 1
                continue
        a = analyze(m, cfg, now, stored_thresholds.get(m.id))
        c.analyses.append(a)
        if a.decision:
            if confidence_fn:
                a.decision.confidence = confidence_fn(a.decision.logic, a.decision.market)
            c.selections.append(a.decision)
        else:
            c.skipped.append({"match_id": m.id, "match": f"{m.home} - {m.away}", "reason": a.skip_reason})
    return c
