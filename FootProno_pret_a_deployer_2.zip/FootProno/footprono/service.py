from __future__ import annotations
from datetime import datetime, timezone
from .config import Config
from .engine import build_coupon
from .models import Match, parse_dt
from .storage import Store


def run(payload: dict, cfg: Config, window: int, mode="both", db_path=None, save=False, now=None) -> dict:
    """payload = {"source": "1xbet (import manuel)", "collected_at": ISO, "matches": [...]}"""
    now = now or datetime.now(timezone.utc)
    collected = parse_dt(payload.get("collected_at"))
    matches = [Match.from_dict(m, collected) for m in payload.get("matches", [])]
    store = Store(db_path) if db_path else None
    stored = {m.id: store.get_thresholds(m.id) for m in matches} if store else {}
    stored = {k: v for k, v in stored.items() if v}
    coupon = build_coupon(matches, cfg, now, window, mode, stored, store.confidence(cfg) if store else None)
    if store and save:
        by_id = {m.id: m for m in matches}
        for a in coupon.analyses:
            store.save_match(by_id[a.match_id])
            if by_id[a.match_id].status != "live":
                store.save_thresholds(a.match_id, a.thresholds)
        for d in coupon.selections:
            store.save_prediction(d)
        for s in coupon.skipped:
            store.save_skip(s["match_id"], s["reason"])
    out = coupon.to_dict()
    out["source"] = payload.get("source", "inconnue")
    return out


def render_text(c: dict) -> str:
    L = [f"COUPON — source : {c.get('source')} — généré {c['generated_at']} — fenêtre {c['window_minutes']} min ({c['mode']})", ""]
    if not c["selections"]:
        L.append("Aucune sélection : aucune règle applicable avec les données disponibles.")
    for d in c["selections"]:
        L += [f"▶ {d['home']} - {d['away']} [{d['competition']}] ({d['kind']})",
              f"   Marché : {d['selection']}", f"   Logique : {d['logic']} — {d['confidence']}",
              f"   Données collectées : {d['collected_at'] or 'heure inconnue'}",
              *[f"   · {t}" for t in d["trace"]], ""]
    if c["skipped"]:
        L.append("Matchs ignorés :")
        L += [f"   - {s['match']} : {s['reason']}" for s in c["skipped"]]
    L += ["", c["disclaimer"]]
    return "\n".join(L)
