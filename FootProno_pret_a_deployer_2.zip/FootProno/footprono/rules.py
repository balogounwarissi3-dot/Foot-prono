"""Règles déterministes. Aucune donnée n'est inventée : en cas de doute -> pas de pronostic."""
from __future__ import annotations
from .models import Decision, Match

EPS = 1e-9
SIDES = ("home", "away")


def other(side):
    return "away" if side == "home" else "home"


def _decision(match, kind, logic, market, selection, params, stats, trace):
    return Decision(match.id, match.competition, match.home, match.away, kind, logic, market,
                    selection, params, stats, list(trace),
                    match.collected_at.isoformat() if match.collected_at else None)


# ---------------------------------------------------------------- avant-match
def classify_regularity(goals, cfg):
    """'strict' (aucun match sans but), 'slight' (<= slight_max_blanks), 'none',
    ou None si l'échantillon est insuffisant. `goals` : du plus récent au plus ancien."""
    if len(goals) < cfg.sample_size:
        return None
    blanks = sum(1 for g in goals[: cfg.sample_size] if g == 0)
    if blanks == 0:
        return "strict"
    if blanks <= cfg.slight_max_blanks:
        return "slight"
    return "none"


def clean_sheet_wins(match: Match) -> dict:
    res = {match.home: 0, match.away: 0}
    for m in match.h2h:
        if m.home_goals > m.away_goals and m.away_goals == 0 and m.home in res:
            res[m.home] += 1
        elif m.away_goals > m.home_goals and m.home_goals == 0 and m.away in res:
            res[m.away] += 1
    return res


def _regularity_logic(match, cfg, logic, allow_slight):
    trace = []
    rh = classify_regularity(match.home_scored, cfg)
    ra = classify_regularity(match.away_scored, cfg)
    trace.append(f"régularité {match.home}={rh}, {match.away}={ra} (échantillon {cfg.sample_size})")
    if rh is None or ra is None:
        trace.append("historique insuffisant pour cette logique")
        return None, trace
    ok = ("strict", "slight") if allow_slight else ("strict",)
    h_ok, a_ok = rh in ok, ra in ok
    cs = clean_sheet_wins(match) if match.h2h else None
    stats = {"home_last_scored": match.home_scored[: cfg.sample_size],
             "away_last_scored": match.away_scored[: cfg.sample_size],
             "regularity": {"home": rh, "away": ra}, "h2h_clean_sheet_wins": cs}
    if h_ok and a_ok:
        if cfg.both_regular_total_line is None:
            trace.append("deux équipes régulières : marché total non validé -> aucun pronostic")
            return None, trace
        line = cfg.both_regular_total_line
        trace.append(f"deux équipes régulières -> total > {line}")
        return _decision(match, "prematch", logic, "total_over", f"Plus de {line} buts dans le match",
                         {"line": line}, stats, trace), trace
    if h_ok != a_ok:
        side = "home" if h_ok else "away"
        team, opp = match.team(side), match.team(other(side))
        if cfg.h2h_block_enabled and cs and cs[opp] > cs[team]:
            trace.append(f"bloqué : {opp} a plus de victoires sans encaisser en face-à-face ({cs[opp]} > {cs[team]})")
            return None, trace
        trace.append(f"seule {team} remplit les critères -> plus de 0,5 but")
        return _decision(match, "prematch", logic, "team_over_0_5", f"{team} : plus de 0,5 but",
                         {"side": side}, stats, trace), trace
    trace.append("aucune équipe ne remplit les critères")
    return None, trace


def logic1(match, cfg):
    """Analyse renforcée : régularité stricte + confrontations directes (facultatives)."""
    return _regularity_logic(match, cfg, "L1", allow_slight=False)


def logic2(match, cfg):
    """Régularité élargie (tolérance d'une exception), fonctionne sans confrontations directes."""
    return _regularity_logic(match, cfg, "L2", allow_slight=True)


def compute_thresholds(match, cfg):
    """Seuil individuel par équipe : plus petit seuil t tel que >= 80 % des matchs ont < t buts."""
    out = {}
    for side, goals in (("home", match.home_scored), ("away", match.away_scored)):
        if len(goals) < cfg.threshold_sample_size:
            return None
        sample = goals[: cfg.threshold_sample_size]
        out[side] = None
        for t in sorted(cfg.thresholds):
            if sum(1 for g in sample if g < t) / len(sample) >= cfg.threshold_share - EPS:
                out[side] = t
                break
    return out


def logic3(match, cfg, thresholds=None):
    trace = []
    th = thresholds if thresholds is not None else compute_thresholds(match, cfg)
    if th is None:
        return None, ["historique insuffisant pour les seuils"]
    trace.append(f"seuils individuels : {match.home}={th['home']}, {match.away}={th['away']}")
    if th["home"] is None or th["away"] is None:
        trace.append("les deux équipes n'ont pas de seuil -> aucun pronostic")
        return None, trace
    s = th["home"] + th["away"]
    low, high = s - cfg.range_low_offset, s + cfg.range_high_offset
    trace.append(f"somme {s} -> fourchette {low}-{high}")
    sel = f"Total de buts entre {low} et {high} (à faire correspondre au marché réel du bookmaker)"
    stats = {"thresholds": th, "sum": s,
             "home_last_scored": match.home_scored[: cfg.threshold_sample_size],
             "away_last_scored": match.away_scored[: cfg.threshold_sample_size]}
    return _decision(match, "prematch", "L3", "total_range", sel, {"low": low, "high": high},
                     stats, trace), trace


# ----------------------------------------------------------------------- live
def _stats_usable(lv, cfg, now):
    if not (lv.home.complete() and lv.away.complete()):
        return False, "statistiques incomplètes"
    if lv.stats_at is None:
        return False, "heure des statistiques inconnue"
    age = (now - lv.stats_at).total_seconds()
    if age < -60:
        return False, "heure des statistiques dans le futur (incohérent)"
    if age > cfg.live_max_age_seconds:
        return False, f"statistiques trop anciennes ({int(age)} s)"
    return True, ""


def evaluate_live(match, cfg, now, prematch_thresholds=None):
    """Retourne (decision|None, raison_si_aucune, trace). Seuils pré-match conservés, jamais recalculés."""
    lv, trace = match.live, []
    if (lv is None or lv.minute is None or lv.home_goals is None or lv.away_goals is None
            or lv.minute > 130):
        return None, "données live insuffisantes", ["minute/score absents ou incohérents"]
    base = {"minute": lv.minute, "score": f"{lv.home_goals}-{lv.away_goals}",
            "prematch_thresholds": prematch_thresholds}
    ok, why = _stats_usable(lv, cfg, now)
    if ok and lv.minute >= cfg.live_min_minute:
        for side in SIDES:
            me, op = getattr(lv, side), getattr(lv, other(side))
            team = match.team(side)
            sup = me.shots_on > op.shots_on and me.shots_off > op.shots_off
            vol = me.dangerous_attacks >= cfg.min_dangerous_attacks
            st = dict(base, dangerous_attacks={"home": lv.home.dangerous_attacks, "away": lv.away.dangerous_attacks},
                      shots_on={"home": lv.home.shots_on, "away": lv.away.shots_on},
                      shots_off={"home": lv.home.shots_off, "away": lv.away.shots_off})
            trace.append(f"{team}: attaques dangereuses {me.dangerous_attacks} vs {op.dangerous_attacks}, "
                         f"tirs cadrés {me.shots_on}/{op.shots_on}, non cadrés {me.shots_off}/{op.shots_off}")
            if not (sup and vol):
                continue
            if me.dangerous_attacks > cfg.dominance_next_goal_ratio * op.dangerous_attacks + EPS:
                trace.append(f"domination > {cfg.dominance_next_goal_ratio}x + supériorité des tirs -> prochain but")
                return _decision(match, "live", "LIVE_NEXT_GOAL", "next_goal", f"Prochain but : {team}",
                                 {"side": side}, st, trace), None, trace
            if me.dangerous_attacks >= cfg.dominance_over_ratio * op.dangerous_attacks - EPS:
                if cfg.over_requires_goalless and (lv.home_goals + lv.away_goals) > 0:
                    trace.append("domination >= seuil mais des buts sont déjà marqués : règle non déclenchée")
                    continue
                trace.append(f"domination >= {cfg.dominance_over_ratio}x + supériorité des tirs -> plus de 0,5 but")
                return _decision(match, "live", "LIVE_OVER_0_5", "total_over", "Plus de 0,5 but dans le match",
                                 {"line": 0.5}, st, trace), None, trace
    if cfg.underdog_rule_enabled and match.favorite:
        fav, dog = match.favorite, other(match.favorite)
        g = {"home": lv.home_goals, "away": lv.away_goals}
        if g[dog] >= 1 and g[fav] == 0:
            team = match.team(fav)
            trace.append(f"non-favori a marqué, favori à 0 -> {team} plus de 0,5 but")
            return _decision(match, "live", "LIVE_UNDERDOG", "team_over_0_5", f"{team} : plus de 0,5 but",
                             {"side": fav}, dict(base), trace), None, trace
    if not ok:
        reason = f"données live insuffisantes ({why})"
    elif lv.minute < cfg.live_min_minute:
        reason = f"règles de domination à partir de la {cfg.live_min_minute}e minute"
    else:
        reason = "aucune règle live applicable"
    return None, reason, trace
