"""Suivi des performances (SQLite). Les pronostics sont enregistrés AVANT le résultat."""
from __future__ import annotations
import json, sqlite3
from datetime import datetime, timezone

SCHEMA = """
CREATE TABLE IF NOT EXISTS matches(id TEXT PRIMARY KEY, payload TEXT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS thresholds(match_id TEXT PRIMARY KEY, data TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS predictions(
  id INTEGER PRIMARY KEY AUTOINCREMENT, match_id TEXT, competition TEXT, kind TEXT, logic TEXT,
  market TEXT, selection TEXT, params TEXT, stats TEXT, trace TEXT, collected_at TEXT, created_at TEXT,
  status TEXT DEFAULT 'pending', result TEXT);
CREATE TABLE IF NOT EXISTS skips(id INTEGER PRIMARY KEY AUTOINCREMENT, match_id TEXT, reason TEXT, created_at TEXT);
"""


def _now():
    return datetime.now(timezone.utc).isoformat()


def evaluate(market, params, hg, ag, next_goal=None):
    """-> 'won' | 'lost' | 'unevaluable'. next_goal: 'home' | 'away' | 'none' | None."""
    total = hg + ag
    if market == "team_over_0_5":
        return "won" if (hg if params["side"] == "home" else ag) >= 1 else "lost"
    if market == "total_over":
        return "won" if total > params["line"] else "lost"
    if market == "total_range":
        return "won" if params["low"] <= total <= params["high"] else "lost"
    if market == "next_goal":
        if next_goal is None:
            return "unevaluable"
        return "won" if next_goal == params["side"] else "lost"
    return "unevaluable"


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)

    def save_match(self, m):
        self.db.execute("INSERT OR REPLACE INTO matches VALUES(?,?,?)", (m.id, json.dumps(m.raw), _now()))
        self.db.commit()

    def save_thresholds(self, match_id, th):
        """INSERT OR IGNORE : les seuils pré-match ne sont JAMAIS écrasés (conservés pendant le live)."""
        if th is not None:
            self.db.execute("INSERT OR IGNORE INTO thresholds VALUES(?,?,?)", (match_id, json.dumps(th), _now()))
            self.db.commit()

    def get_thresholds(self, match_id):
        r = self.db.execute("SELECT data FROM thresholds WHERE match_id=?", (match_id,)).fetchone()
        return json.loads(r["data"]) if r else None

    def save_prediction(self, d):
        dup = self.db.execute("SELECT id FROM predictions WHERE match_id=? AND kind=? AND logic=? AND market=? "
                              "AND params=?", (d.match_id, d.kind, d.logic, d.market, json.dumps(d.params))).fetchone()
        if dup:
            return dup["id"]
        cur = self.db.execute(
            "INSERT INTO predictions(match_id,competition,kind,logic,market,selection,params,stats,trace,"
            "collected_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (d.match_id, d.competition, d.kind, d.logic, d.market, d.selection, json.dumps(d.params),
             json.dumps(d.stats), json.dumps(d.trace), d.collected_at, _now()))
        self.db.commit()
        return cur.lastrowid

    def save_skip(self, match_id, reason):
        self.db.execute("INSERT INTO skips(match_id,reason,created_at) VALUES(?,?,?)", (match_id, reason, _now()))
        self.db.commit()

    def settle(self, match_id, hg, ag, next_goal=None):
        rows = self.db.execute("SELECT * FROM predictions WHERE match_id=? AND status='pending'", (match_id,)).fetchall()
        for r in rows:
            st = evaluate(r["market"], json.loads(r["params"]), hg, ag, next_goal)
            self.db.execute("UPDATE predictions SET status=?, result=? WHERE id=?",
                            (st, json.dumps({"home_goals": hg, "away_goals": ag, "next_goal": next_goal}), r["id"]))
        self.db.commit()
        return len(rows)

    def void(self, match_id):
        self.db.execute("UPDATE predictions SET status='void' WHERE match_id=? AND status='pending'", (match_id,))
        self.db.commit()

    def stats(self, by=("kind", "logic", "market", "competition")):
        cols = ",".join(by)
        rows = self.db.execute(
            f"SELECT {cols}, COUNT(*) n, SUM(status='won') won, SUM(status='lost') lost, "
            "SUM(status='void') void, SUM(status='unevaluable') unevaluable, SUM(status='pending') pending "
            f"FROM predictions GROUP BY {cols}").fetchall()
        out = []
        for r in rows:
            d = dict(r)
            done = (d["won"] or 0) + (d["lost"] or 0)
            d["success_rate"] = round(d["won"] / done, 3) if done else None
            out.append(d)
        return out

    def confidence(self, cfg):
        def fn(logic, market):
            r = self.db.execute("SELECT SUM(status='won') w, SUM(status='lost') l FROM predictions "
                                "WHERE logic=? AND market=?", (logic, market)).fetchone()
            w, l = r["w"] or 0, r["l"] or 0
            if w + l < cfg.confidence_min_sample:
                return "confiance non évaluée"
            rate = w / (w + l)
            return "élevée" if rate >= cfg.confidence_high else "moyenne" if rate >= cfg.confidence_medium else "faible"
        return fn
