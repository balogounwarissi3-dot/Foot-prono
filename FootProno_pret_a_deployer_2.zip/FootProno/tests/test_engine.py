import os, sys, tempfile, unittest
from datetime import datetime, timedelta, timezone
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from footprono.config import Config
from footprono.models import Match
from footprono import rules
from footprono.engine import analyze, build_coupon
from footprono.storage import Store, evaluate
from footprono.demo import demo_payload

NOW = datetime(2026, 11, 2, 12, 0, tzinfo=timezone.utc)
CFG = Config()


def pre(h, a, **kw):
    d = dict(id="x", home="A", away="B", status="scheduled", home_last_scored=h, away_last_scored=a, **kw)
    return Match.from_dict(d)


def live(minute=30, hg=0, ag=0, da=(14, 5), on=(4, 1), off=(5, 2), age=10, fav=None):
    d = dict(id="l", home="A", away="B", status="live", favorite=fav, live={
        "minute": minute, "home_goals": hg, "away_goals": ag, "stats_at": (NOW - timedelta(seconds=age)).isoformat(),
        "home": dict(dangerous_attacks=da[0], shots_on_target=on[0], shots_off_target=off[0]),
        "away": dict(dangerous_attacks=da[1], shots_on_target=on[1], shots_off_target=off[1])})
    return Match.from_dict(d)


class Regularity(unittest.TestCase):
    def test_classes(self):
        c = lambda g: rules.classify_regularity(g, CFG)
        self.assertEqual(c([1, 2, 1, 1, 3]), "strict")
        self.assertEqual(c([1, 0, 1, 1, 3]), "slight")
        self.assertEqual(c([0, 0, 1, 1, 3]), "none")
        self.assertIsNone(c([1, 1]))

    def test_logic1_one_team(self):
        d, _ = rules.logic1(pre([1, 2, 1, 1, 2], [0, 0, 1, 2, 1]), CFG)
        self.assertEqual((d.logic, d.market, d.params), ("L1", "team_over_0_5", {"side": "home"}))

    def test_logic1_ignores_slight_logic2_accepts(self):
        m = pre([1, 0, 1, 1, 2], [0, 0, 1, 2, 1])
        self.assertIsNone(rules.logic1(m, CFG)[0])
        self.assertEqual(rules.logic2(m, CFG)[0].logic, "L2")

    def test_both_regular_not_validated_no_pick(self):
        m = pre([1, 1, 1, 1, 1], [2, 1, 1, 1, 1])
        self.assertIsNone(rules.logic1(m, CFG)[0])
        cfg = Config(both_regular_total_line=1.5)
        self.assertEqual(rules.logic1(m, cfg)[0].market, "total_over")

    def test_h2h_block_and_optional(self):
        h2h = [dict(home="B", away="A", home_goals=2, away_goals=0)] * 2
        m = pre([1, 1, 1, 1, 1], [0, 0, 1, 2, 1], h2h=h2h)
        self.assertIsNone(rules.logic1(m, CFG)[0])
        self.assertIsNotNone(rules.logic1(pre([1, 1, 1, 1, 1], [0, 0, 1, 2, 1]), CFG)[0])


class Thresholds(unittest.TestCase):
    def test_80_percent_edge(self):
        self.assertEqual(rules.compute_thresholds(pre([1, 2, 0, 1, 5], [1, 1, 1, 1, 1]), CFG)["home"], 3)  # 4/5
        self.assertIsNone(rules.compute_thresholds(pre([1, 4, 0, 1, 5], [1, 1, 1, 1, 1]), CFG)["home"])  # 3/5

    def test_range_and_logic3(self):
        cfg = Config(thresholds=(2, 3))
        m = pre([1, 0, 2, 0, 1], [0, 1, 1, 0, 1])  # 2 matchs sans but chacun : pas de régularité
        th = rules.compute_thresholds(m, cfg)
        self.assertEqual(th, {"home": 2, "away": 2})
        d, _ = rules.logic3(m, cfg)
        self.assertEqual((d.params["low"], d.params["high"]), (3, 4))

    def test_insufficient_history_skipped(self):
        a = analyze(pre([1, 2], []), CFG, NOW)
        self.assertIsNone(a.decision)
        self.assertIn("insuffisant", a.skip_reason)

    def test_invalid_history_not_repaired(self):
        m = pre([1, "x", 1, 1, 1], [1, 1, 1, 1, 1])
        self.assertEqual(m.home_scored, [])
        self.assertIsNone(analyze(m, CFG, NOW).decision)


class Live(unittest.TestCase):
    def test_next_goal_strictly_above_2(self):
        d, _, _ = rules.evaluate_live(live(da=(20, 10)), CFG, NOW)   # ratio exactement 2 -> pas "prochain but"
        self.assertNotEqual(d.logic if d else None, "LIVE_NEXT_GOAL")
        d, _, _ = rules.evaluate_live(live(da=(21, 10)), CFG, NOW)
        self.assertEqual(d.logic, "LIVE_NEXT_GOAL")

    def test_over_at_1_8(self):
        d, _, _ = rules.evaluate_live(live(da=(9, 5)), CFG, NOW)
        self.assertEqual(d.logic, "LIVE_OVER_0_5")
        d, why, _ = rules.evaluate_live(live(da=(9, 5), hg=1), CFG, NOW)  # déjà un but
        self.assertIsNone(d)

    def test_needs_both_shot_categories(self):
        d, _, _ = rules.evaluate_live(live(on=(4, 1), off=(2, 2)), CFG, NOW)
        self.assertIsNone(d)

    def test_before_18_and_missing_and_stale(self):
        self.assertIsNone(rules.evaluate_live(live(minute=17), CFG, NOW)[0])
        self.assertIn("insuffisantes", rules.evaluate_live(live(age=900), CFG, NOW)[1])
        m = live(); m.live.away.shots_on = None
        self.assertIn("insuffisantes", rules.evaluate_live(m, CFG, NOW)[1])

    def test_underdog_rule(self):
        d, _, _ = rules.evaluate_live(live(hg=0, ag=1, da=(6, 7), on=(1, 2), off=(2, 3), fav="home"), CFG, NOW)
        self.assertEqual((d.logic, d.params), ("LIVE_UNDERDOG", {"side": "home"}))
        self.assertIsNone(rules.evaluate_live(live(hg=0, ag=1, da=(6, 7), fav=None), CFG, NOW)[0])

    def test_prematch_thresholds_kept(self):
        th = {"home": 3, "away": 3}
        d, _, _ = rules.evaluate_live(live(), CFG, NOW, th)
        self.assertEqual(d.stats["prematch_thresholds"], th)


class CouponAndStorage(unittest.TestCase):
    def test_demo_coupon_not_padded(self):
        from footprono.service import run
        res = run(demo_payload(NOW), CFG, 120, "both", now=NOW)
        logics = sorted(d["logic"] for d in res["selections"])
        self.assertEqual(logics, ["L1", "L2", "L3", "LIVE_NEXT_GOAL", "LIVE_OVER_0_5", "LIVE_UNDERDOG"])
        self.assertEqual(len(res["skipped"]), 3)  # D4, L4, L5

    def test_window_filter(self):
        ms = [pre([1] * 5, [0, 0, 1, 1, 1], kickoff=(NOW + timedelta(minutes=90)).isoformat())]
        self.assertEqual(len(build_coupon(ms, CFG, NOW, 60).selections), 0)
        self.assertEqual(len(build_coupon(ms, CFG, NOW, 120).selections), 1)

    def test_evaluate_and_confidence(self):
        self.assertEqual(evaluate("total_range", {"low": 4, "high": 5}, 3, 2), "won")
        self.assertEqual(evaluate("next_goal", {"side": "home"}, 1, 0), "unevaluable")
        with tempfile.TemporaryDirectory() as t:
            s = Store(os.path.join(t, "t.db"))
            self.assertEqual(s.confidence(CFG)("L1", "team_over_0_5"), "confiance non évaluée")

    def test_thresholds_never_overwritten(self):
        with tempfile.TemporaryDirectory() as t:
            s = Store(os.path.join(t, "t.db"))
            s.save_thresholds("m", {"home": 3, "away": 3}); s.save_thresholds("m", {"home": 2, "away": 2})
            self.assertEqual(s.get_thresholds("m"), {"home": 3, "away": 3})


if __name__ == "__main__":
    unittest.main()
